class Musica{
    String _nome ="";
  String _artista="";

  String get nome => _nome;

  set nome(String nome) {
    _nome = nome;
  }


  String get artista => _artista;

  set artista(String artista) {
    _artista = artista;
  }


}