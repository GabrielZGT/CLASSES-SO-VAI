class Pessoa{

  int _idade = 0;
 String _nome ="";
List<Pessoa>lista =[];

  String get nome => _nome;
  set nome(String? nome) {
    _nome = _nome;
  }

  int get idade => _idade;

  set idade(int idade) {
    _idade = idade;
  }
    void adicionaAmigo(Pessoa  pessoa){
      this.lista.add(pessoa);
  print("Liked");
 }

  bool briga(Pessoa pessoa){
    if(lista.contains(Pessoa)){
      lista.removeWhere((roger) => roger ==pessoa);
      print("deu ruim");
      return true;

    }
    return false;
  }
}

 